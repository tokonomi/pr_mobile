import 'package:flutter/material.dart';
import 'package:partners_room/src/widgets/home_cards.dart';

import './widgets/home_search.dart';
import './widgets/home_fyb.dart';
import './widgets/home_products.dart';

class Home extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('PARTNERS ROOM')),
        body: Container(
          padding: EdgeInsets.only(left: 20, right: 20),
          child: ListView(
            children: [
              HomeSearch(),
              HomeCard(),
              Fyb(),
              HomeProducts()
            ],
          ))
    );
  }
}